package attend;

public class AttendMain {
	
	public void showMain() {
		while(true) {
			System.out.println("");
		}
	}

}
