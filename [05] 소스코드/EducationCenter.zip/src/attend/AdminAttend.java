package attend;

public class AdminAttend {

}
